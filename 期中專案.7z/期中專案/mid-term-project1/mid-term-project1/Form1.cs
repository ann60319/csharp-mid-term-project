﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//sql namespace
using System.Collections;
//button1.ForeColor= Color.FromArgb(192, 192, 192);RGB
namespace mid_term_project1
{
    public partial class Form1 : Form
    {
        SqlConnectionStringBuilder scsb;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "mid-term";//database name
            scsb.IntegratedSecurity = true;
            //*******ado.net connection process over*********
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime.Now.ToShortTimeString();
            DateTime dt = DateTime.Now;
            lbltimenow.Text = string.Format("{0}", dt);
        }

        private void btntimenow_Click(object sender, EventArgs e)
        {
            if (tborderdate.Text == "")
            {
                tborderdate.Text += lbltimenow.Text;
            }
            else
            {
                tborderdate.Text = "";
                tborderdate.Text += lbltimenow.Text;
            }

        }

        /*private void tabControl1_SelectedIndexChanged(Object sender, EventArgs e)
        {
            
              SqlConnection con = new SqlConnection(scsb.ToString());
              con.Open();
              string strSQL = "select product from product1 ";
              SqlCommand cmd = new SqlCommand(strSQL, con);
              cmd.Parameters.AddWithValue("@Searchproduct", "%" + tbproduct.Text + "%");
              SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbproduct.Items.Add(reader["product"]);
            }
            reader.Close();
            con.Close();



        }*/


        private void btnadd_p_Click(object sender, EventArgs e)
        {

            if (tbproduct.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "insert into product1 ( [product], [price], [manufactor date], [stock]) VALUES (@Newproduct,@Newprice,@Newmanufactordate,@Newstock)";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                //cmd.Parameters.AddWithValue("@P_ID", intp_id);
                cmd.Parameters.AddWithValue("@Newproduct", tbproduct.Text);
                cmd.Parameters.AddWithValue("@Newprice", tbprice.Text);
                cmd.Parameters.AddWithValue("@Newmanufactordate", (DateTime)dtpproducedate.Value);
                cmd.Parameters.AddWithValue("@Newstock", tbstockquantity.Text);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                //MessageBox.Show("資料新增完畢,共" + rows.ToString()+"筆");
                lbproduct.Items.Add(tbproduct.Text);
                lblp_id.Text = "";
                tbproduct.Text = "";
                tbprice.Text = "";
                dtpproducedate.Value = DateTime.Now;
                tbstockquantity.Text = "";

            }
            else
            {
                MessageBox.Show("請輸入新增產品名稱");
            }

        }

        private void btnrevise_p_Click(object sender, EventArgs e)
        {
            int intp_id = 0;
            Int32.TryParse(lblp_id.Text, out intp_id);

            if (intp_id >= 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();

                string strSQL = "update product1 set product=@Newproduct,price=@Newprice, [manufactor date]=@Newproducedate, stock=@Newstock where Pro_id=@Searchid";

                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Searchid", lblp_id.Text);
                cmd.Parameters.AddWithValue("@Newproduct", tbproduct.Text);
                cmd.Parameters.AddWithValue("@Newprice", tbprice.Text);
                cmd.Parameters.AddWithValue("@Newproducedate", (DateTime)dtpproducedate.Value);
                cmd.Parameters.AddWithValue("@Newstock", tbstockquantity.Text);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                //MessageBox.Show("資料更動成功，共影響: " + rows.ToString() + "筆資料");

                lblp_id.Text = "";
                tbproduct.Text = "";
                tbprice.Text = "";
                dtpproducedate.Value = DateTime.Now;
                tbstockquantity.Text = "";

            }
            else
            {
                MessageBox.Show("資料異動失敗，請重新操作一次");
            }

        }


        private void btnremove_p_Click(object sender, EventArgs e)
        {
            int p_id = 0;
            Int32.TryParse(lblp_id.Text, out p_id);
            if (p_id >= 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "delete from product1 where Pro_id=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchId", p_id);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("資料刪除完畢,共影響" + rows.ToString() + "筆");

                lblp_id.Text = "";
                tbproduct.Text = "";
                tbprice.Text = "";
                dtpproducedate.Value = DateTime.Now;
                tbstockquantity.Text = "";

            }

        }

        private void btnsearch_p_Click(object sender, EventArgs e)
        {
            if (tbproductsearch.Text != "")
            {
                lbproduct.Items.Clear();
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();

                string strSQL = "select* from product1 where product like @Searchproduct";

                SqlCommand cmd = new SqlCommand(strSQL, con);

                //加入參數
                cmd.Parameters.AddWithValue("@Searchproduct", "%" + tbproductsearch.Text + "%");

                //讀出參數
                SqlDataReader reader = cmd.ExecuteReader();

                bool a = reader.Read();

                if (a == false)
                {
                    MessageBox.Show("查無此產品");
                    lblp_id.Text = "";
                    tbproduct.Text = "";
                    tbprice.Text = "";
                    dtpproducedate.Value = DateTime.Now;
                    tbstockquantity.Text = "";

                }

                while (a)
                {
                    lbproduct.Items.Add(reader["product"]);
                    a = reader.Read();

                    lblp_id.Text = "";
                    tbproduct.Text = "";
                    tbprice.Text = "";
                    dtpproducedate.Value = DateTime.Now;
                    tbstockquantity.Text = "";

                }

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("請輸入產品名稱以利尋找");
            }
        }

        private void btnallproduct_Click(object sender, EventArgs e)
        {
            lbproduct.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select*from product1 where product like @Product";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Product", "%" + tbproduct.Text + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbproduct.Items.Add(reader["product"]);
            }
            reader.Close();
            con.Close();
        }

        private void lbproduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSearchproduct = lbproduct.SelectedItem.ToString();

            if (strSearchproduct != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select*from product1 where product like @Searchproduct";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Searchproduct", "%" + strSearchproduct + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    lblp_id.Text = string.Format("{0}", reader["Pro_id"]);
                    tbproduct.Text = string.Format("{0}", reader["product"]);
                    tbprice.Text = string.Format("{0}", reader["price"]);
                    dtpproducedate.Value = (DateTime)reader["manufactor date"];
                    tbstockquantity.Text = string.Format("{0}", reader["stock"]);

                }
                else
                {
                    MessageBox.Show("查無此產品");
                    lblp_id.Text = "";
                    tbproduct.Text = "";
                    tbprice.Text = "";
                    dtpproducedate.Value = DateTime.Now;
                    tbstockquantity.Text = "";
                }
                reader.Close();
                con.Close();
            }

        }

        private void btnallcus_Click(object sender, EventArgs e)
        {

            lbcus.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select*from customerlist where cus_name like @Cus_name";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Cus_name", "%" + tbcus_name.Text + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbcus.Items.Add(reader["cus_name"]);
            }
            reader.Close();
            con.Close();
        }

        private void btnadd_c_Click(object sender, EventArgs e)
        {

            if (tbcus_name.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "insert into customerlist ([cus_name], [cus_tel], [address], [relationship], [all_order_number], [all_consume_amount]) VALUES (@Newname,@Newcus_tel,@Newaddress,@relationship,@Newall_orders,@Newall_paid)";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                //cmd.Parameters.AddWithValue("@Newcus_id", lblcus_id.Text);
                cmd.Parameters.AddWithValue("@Newname", tbcus_name.Text);
                cmd.Parameters.AddWithValue("@Newcus_tel", tbcus_tel.Text);
                cmd.Parameters.AddWithValue("@Newaddress", tbcus_address.Text);
                cmd.Parameters.AddWithValue("@relationship", tbcus_relationship.Text);
                cmd.Parameters.AddWithValue("@Newall_orders", lblsum_orders.Text);
                cmd.Parameters.AddWithValue("@Newall_paid", lblsum_paid.Text);

                int rows = cmd.ExecuteNonQuery();
                con.Close();

                lbcus.Items.Clear();
                lbcus.Items.Add(tbcus_name.Text);

                lblcus_id.Text = "";
                tbcus_name.Text = "";
                tbcus_tel.Text = "";
                tbcus_address.Text = "";
                tbcus_relationship.Text = "";
                lblsum_orders.Text = "";
                lblsum_paid.Text = "";

            }
            else
            {
                MessageBox.Show("請輸入新增客戶姓名");
            }
        }

        private void btnrevise_c_Click(object sender, EventArgs e)
        {
            int intcus_id = 0;
            Int32.TryParse(lblcus_id.Text, out intcus_id);

            if (intcus_id > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();

                string strSQL = "update customerlist set cus_name=@Newcus_name, cus_tel=@Newcus_tel, address=@Newaddress, relationship=@Newrelationship where cus_id=@cus_id";

                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@cus_id", lblcus_id.Text);
                cmd.Parameters.AddWithValue("@Newcus_name", tbcus_name.Text);
                cmd.Parameters.AddWithValue("@Newcus_tel", tbcus_tel.Text);
                cmd.Parameters.AddWithValue("@Newaddress", tbaddress.Text);
                cmd.Parameters.AddWithValue("@Newrelationship", tbcus_relationship.Text);

                int rows = cmd.ExecuteNonQuery();
                con.Close();

                //MessageBox.Show("資料更動成功，共影響: " + rows.ToString() + "筆資料");
                lblcus_id.Text = "";
                tbcus_name.Text = "";
                tbcus_tel.Text = "";
                tbaddress.Text = "";
                tbcus_relationship.Text = "";
            }
            else
            {
                MessageBox.Show("資料異動失敗，請重新操作一次");
            }
        }

        private void btnremove_c_Click(object sender, EventArgs e)
        {
            int cus_id = 0;
            Int32.TryParse(lblcus_id.Text, out cus_id);
            if (cus_id > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "delete from customerlist where cus_id=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchId", cus_id);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("資料刪除完畢,共影響" + rows.ToString() + "筆");

                lblcus_id.Text = "";
                tbcus_name.Text = "";
                tbcus_tel.Text = "";
                tbcus_address.Text = "";
                tbcus_relationship.Text = "";
                lblsum_orders.Text = "";
                lblsum_paid.Text = "";

            }
        }

        private void btnsearch_c_Click(object sender, EventArgs e)
        {
            if (tbcus_name.Text != "")
            {
                lbcus.Items.Clear();
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();

                string strSQL = "select* from customerlist where cus_name like @Searchcus";

                SqlCommand cmd = new SqlCommand(strSQL, con);

                //加入參數
                cmd.Parameters.AddWithValue("@Searchcus", "%" + tbcus_name.Text + "%");

                //讀出參數
                SqlDataReader reader = cmd.ExecuteReader();

                bool a = reader.Read();

                if (a == false)
                {
                    MessageBox.Show("查無此客戶");
                    lblcus_id.Text = "";
                    tbcus_name.Text = "";
                    tbcus_tel.Text = "";
                    tbcus_address.Text = "";
                    tbcus_relationship.Text = "";
                    lblsum_orders.Text = "";
                    lblsum_paid.Text = "";

                }

                while (a)
                {
                    lbcus.Items.Add(reader["cus_name"]);
                    a = reader.Read();

                    lblcus_id.Text = "";
                    tbcus_name.Text = "";
                    tbcus_tel.Text = "";
                    tbcus_address.Text = "";
                    tbcus_relationship.Text = "";
                    lblsum_orders.Text = "";
                    lblsum_paid.Text = "";
                    
                }
                

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("請輸入客戶姓名以利尋找");
            }
        }

        private void lbcus_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strCus = lbcus.SelectedItem.ToString();

            if (strCus != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from customerlist where cus_name like @Searchcus";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Searchcus", "%" + strCus + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    lblcus_id.Text = string.Format("{0}", reader["cus_id"]);
                    tbcus_name.Text = string.Format("{0}", reader["cus_name"]);
                    tbcus_tel.Text = string.Format("{0}", reader["cus_tel"]);
                    tbcus_address.Text = string.Format("{0}", reader["address"]);
                    tbcus_relationship.Text = string.Format("{0}", reader["relationship"]);
                    lblsum_orders.Text = string.Format("{0}", reader["all_order_number"]);
                    lblsum_paid.Text = string.Format("{0}", reader["all_consume_amount"]);

                }
                else
                {
                    //MessageBox.Show("查無此產品");
                    lblp_id.Text = "";
                    tbproduct.Text = "";
                    tbprice.Text = "";
                    dtpproducedate.Value = DateTime.Now;
                    tbstockquantity.Text = "";
                }
                reader.Close();
                con.Close();
            }

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            lborders.Items.Clear();
            try
            {
                if (cbcus_name.Text != "" && lborderlist.Items.Count != 0)
                {
                    SqlConnection con = new SqlConnection(scsb.ToString());
                    con.Open();
                    string strSQL = "insert into orders ( [cus_name], [cus_tel],[orderdate], [deliverdate], [paid_statement], [delivered_statement]) VALUES (@Newname,@Newcus_tel,@Neworderdate,@Newdeliverdate,@Newpaidstate,@Newdeliverstate)";


                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    //orders
                    cmd.Parameters.AddWithValue("@Newname", cbcus_name.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Newcus_tel", tbphone.Text);
                    cmd.Parameters.AddWithValue("@Neworderdate", Convert.ToDateTime(tborderdate.Text));
                    cmd.Parameters.AddWithValue("@Newdeliverdate", (DateTime)dtpdeliver.Value);
                    cmd.Parameters.AddWithValue("@Newpaidstate", (bool)chkpaid.Checked);
                    cmd.Parameters.AddWithValue("@Newdeliverstate", (bool)chkdelivered.Checked);

                    //orderdetail

                    //int rows = 
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    string strSQL1 = "select Max(order_id) as maximum from orders ";//read max orderid from table orders
                    SqlCommand cmd1 = new SqlCommand(strSQL1, con);
                    SqlDataReader reader = cmd1.ExecuteReader();
                    reader.Read();
                    lblorder_id.Text = string.Format("{0}", reader["maximum"]);

                    reader.Close();
                    con.Close();

                    con.Open();


                    try
                    {
                        foreach (List<string> a in myarrayList)
                        {
                            string strSQL3 = "INSERT into orderdetail ([order_id], [pro_id], [product], [quantity], [total], [discount], [finaltotal]) " +
                             "values (@NewO_id,@NewP_id,@Newproduct,@NewQty,@NewTot,@Newdiscount,@NewF_total)";

                            SqlCommand cmd3 = new SqlCommand(strSQL3, con);

                            cmd3.Parameters.AddWithValue("@NewO_id", lblorder_id.Text);
                            cmd3.Parameters.AddWithValue("@NewP_id", a[0]);
                            cmd3.Parameters.AddWithValue("@Newproduct", a[1]);
                            cmd3.Parameters.AddWithValue("@NewQty", a[2]);
                            cmd3.Parameters.AddWithValue("@NewTot", a[3]);
                            cmd3.Parameters.AddWithValue("@Newdiscount", a[4]);
                            cmd3.Parameters.AddWithValue("@NewF_total", a[5]);


                            int rows = cmd3.ExecuteNonQuery();
                            if (rows != 0)
                            {
                                // MessageBox.Show("ok, I did it");
                            }
                            else
                            {
                                //MessageBox.Show("fail");
                            }


                        }
                    }
                    catch (Exception)
                    {

                        throw;
                    }


                    con.Close();
                    lborders.Items.Add(cbcus_name.Text);
                    lborderlist.Items.Clear();
                    lblorder_id.Text = "";
                    cbcus_name.Text = "";
                    tbphone.Text = "";
                    tborderdate.Text = "";
                    dtpdeliver.Value = DateTime.Today;
                    chkdelivered.Checked = false;
                    chkpaid.Checked = false;
                    tbaddress.Text = "";
                    tbclientrelation.Text = "";
                    lborders.Enabled = false;

                }
            }
            catch (Exception ez)
            {
                MessageBox.Show(ez.ToString());

            }



        }

        void readneworder()
        {

        }

        private void btnrevise_Click(object sender, EventArgs e)
        {

        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            int O_ID = 0;
            Int32.TryParse(lblorder_id.Text, out O_ID);
            if (O_ID >= 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "delete from orders where Order_id= @SearchID";
                    /*"delete from orderdetail where Order_id=@SearchID";*/
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchID", O_ID);
                //lborders.ClearSelected();
                //int k = lborders.SelectedIndex;
                //O_id.Remove(k);
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("訂單刪除完畢");
                O_id.Clear();
                cbcus_name.Items.Clear();
                lblorder_id.Text = "";
                tbphone.Text = "";
                tborderdate.Text = "";
                dtpdeliver.Value = DateTime.Now;
                chkdelivered.Checked = false;
                chkpaid.Checked = false;
                tbaddress.Text = "";
                tbclientrelation.Text ="";
                lbOD_product.Items.Clear();
                lborderlist.Items.Clear();
                amount_count.Text = "0";
                lblfinaltotal.Text = "";
                lbltotal.Text = "";
                cb_discount.Text = "0";
                lborders.Items.Clear();

            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (cbcus_name.Text != "")
            {
                lborders.Items.Clear();
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();

                string strSQL = "select* from orders where cus_name like @Searchcus";

                SqlCommand cmd = new SqlCommand(strSQL, con);

                //加入參數
                cmd.Parameters.AddWithValue("@Searchcus", "%" + cbcus_name.Text + "%");

                //讀出參數
                SqlDataReader reader = cmd.ExecuteReader();

                bool a = reader.Read();

                if (a == false)
                {
                    MessageBox.Show("查無此客戶的訂單紀錄");
                    cbcus_name.Items.Clear();
                }

                while (a)
                {
                    lborders.Items.Add(reader["cus_name"]);
                }

                reader.Close();
                con.Close();
            }
            
        }
        
        private void lborders_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbcus_name.Items.Clear();
            lblorder_id.Text = "";
            tbphone.Text = "";
            tborderdate.Text = "";
            dtpdeliver.Value = DateTime.Now;
            chkdelivered.Checked = false;
            chkpaid.Checked = false;
            tbaddress.Text = "";
            tbclientrelation.Text = "";

            lborderlist.Items.Clear();
            amount_count.Text = "0";
            lblfinaltotal.Text = "";
            lbltotal.Text = "";
            cb_discount.Text = "0";

            
            int k = lborders.SelectedIndex;
            int AL_order_id = Convert.ToInt32(O_id[k]);


            string strorders = lborders.SelectedItem.ToString();

            if (strorders != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select  o.order_id, o.cus_name, o.cus_tel, o.orderdate, o.deliverdate, o.[paid_statement], o.[delivered_statement], od.product, od.quantity, od.total, od.discount, od.finaltotal, c.address, c.relationship, p.price" +
                                 " from orders as o inner join orderdetail as od on o.order_id = od.order_id" +
                                " inner join customerlist as c on o.cus_tel=c.cus_tel " +
                                " inner join product1 as p on od.product=p.product" +
                                " where o.order_id like @Searchid";

                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Searchid", "%" + AL_order_id + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                lborderlist.Items.Clear();

                int sum = 0;
                double discount = 0, sumtotal = 0;
                double d = 0;
                Lboutputallproduct();

                
                while (reader.Read() == true)
                {
                    
                    lblorder_id.Text = string.Format("{0}", reader["order_id"]);

                    cbcus_name.Text = string.Format("{0}", reader["cus_name"]);


                    tbphone.Text = string.Format("{0}", reader["cus_tel"]);

                    //amount_count.Text = string.Format("{0}", reader["quantity"]);
                    tborderdate.Text = string.Format("{0}", (DateTime)reader["orderdate"]);
                    dtpdeliver.Value = (DateTime)reader["deliverdate"];
                    chkpaid.Checked = (bool)reader["paid_statement"];
                    chkdelivered.Checked = (bool)reader["delivered_statement"];
                    tbaddress.Text = string.Format("{0}", reader["address"]);
                    tbclientrelation.Text = string.Format("{0}", reader["relationship"]);

                    sum += (int)reader["quantity"] * (int)reader["price"];
                    lbltotal.Text = string.Format("{0}", sum);
                    d = Convert.ToInt32(reader["discount"]);
                    discount = (d / 10);
                    cb_discount.Text = string.Format("{0}", d);
                    //Console.WriteLine(d);
                    if (cb_discount.Text == "0" || cb_discount.Text == "")
                    {
                        lblfinaltotal.Text = lbltotal.Text;
                    }
                    else
                    {
                        sumtotal = Math.Round((sum * discount), 0);
                        lblfinaltotal.Text = string.Format("{0}", sumtotal);
                    }

                    lborderlist.Items.Add(string.Format("{0}\t,{1:c2}", reader["product"], reader["price"]) + ",數量 : " + string.Format("{0}", reader["quantity"]) + "\n");

                    
                }

                reader.Close();
                con.Close();
            }
        }
        

        int Total, intdiscount = 0;
        double discount = 0, finaltotal = 0;
        //ArrayList Totallist = new ArrayList(); 
        List<int> Totallist = new List<int>();
        List<string> temp1 = new List<string>();
        ArrayList myarrayList = new ArrayList();
        private void btnconfirm_Click(object sender, EventArgs e)//**************************************//
        {
            List<string> myList = new List<string>();
            myList.Add(lbOD_product.SelectedIndex.ToString());
            myList.Add(lbOD_product.SelectedItem.ToString());
            myList.Add(Convert.ToString(amount_count.Value));
            

            Console.WriteLine(lbOD_product.SelectedIndex.ToString().GetType());
            Console.WriteLine(lbOD_product.SelectedItem.ToString().GetType());
            Console.WriteLine(Convert.ToString(amount_count.Value).GetType());

            string str_p = lbOD_product.SelectedItem.ToString();
            string strSum = "";
            int price = 0, qty = 0;
            
            lbltotal.Text = "";

            if (str_p != "")
            {
                double f_tot;
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select price from product1 where product like @Search_p";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Search_p", "%" + str_p + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    
                    
                    lborderlist.Items.Add(string.Format("{0},{1:C2}", str_p, reader["price"]) + "\n" + " 數量: " + amount_count.Value);
                    qty = Convert.ToInt32(amount_count.Value);
                    price = Convert.ToInt32(reader["price"]);
                    Total = Total + (qty * price);
                    //Console.WriteLine(qty);
                    //Console.WriteLine(price);
                    //Console.WriteLine(Total);
                    
                    Totallist.Add(qty*price);
                    strSum = string.Format("{0}", Total);
                    lbltotal.Text = strSum;
                    if (cb_discount.Text == "0")
                    {
                        lblfinaltotal.Text = strSum;
                    }
                    
                    myList.Add(Convert.ToString(price * qty));//one product total
                    myList.Add(cb_discount.Text);
                    
                    Console.WriteLine(Convert.ToString(price * qty).GetType());
                    Console.WriteLine(cb_discount.Text.GetType());


                    if (cb_discount.Text == "9.5")
                    {
                        f_tot = Math.Round((qty * price * 0.95), 0);
                        myList.Add(f_tot.ToString());
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString() + "--------------");
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else if (cb_discount.Text=="9")
                    {
                        f_tot = Math.Round((qty * price * 0.9), 0);
                        Console.WriteLine(f_tot.ToString()+"--------------");
                        myList.Add(f_tot.ToString());
                        
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else if (cb_discount.Text == "8.5")
                    {
                        f_tot = Math.Round((qty * price * 0.85), 0);
                        myList.Add(f_tot.ToString());
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else if (cb_discount.Text == "8")
                    {
                        f_tot = Math.Round((qty * price * 0.8), 0);
                        myList.Add(f_tot.ToString());
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else if (cb_discount.Text == "7.5")
                    {
                        f_tot = Math.Round((qty * price * 0.75), 0);
                        myList.Add(f_tot.ToString());
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else if (cb_discount.Text == "7")
                    {
                        f_tot = Math.Round((qty * price * 0.7), 0);
                        myList.Add(f_tot.ToString());
                        temp1.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                    }
                    else
                    {
                        f_tot = (qty * price);
                        myList.Add(f_tot.ToString());
                        Console.WriteLine(f_tot.ToString().GetType());
                        //myarrayList.Add(f_tot.ToString());    /* myarrayList ????*/
                        temp1.Add(f_tot.ToString());
                        //Console.WriteLine(f_tot.ToString());
                    }

                    //string select = cb_discount.SelectedItem.ToString();
                    //double D_select = Convert.ToDouble(select),f_tot;
                    //f_tot = Math.Round(((D_select/10) * qty*price), 0);
                    Console.WriteLine( myList.Count());
                    myarrayList.Add(myList);
                }
                //Console.WriteLine(myarrayList[0].ToString()+ myarrayList[1].ToString()+ myarrayList[2].ToString()+ myarrayList[3].ToString());
                reader.Close();
                con.Close();

            }

        }
         ArrayList O_id = new ArrayList();
        private void btnallorders_Click(object sender, EventArgs e)
        {
            lborders.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select order_id,cus_name from orders where cus_name like @Searchcus";
            //string strSQL = "select order_id,cus_name from orders where cus_name like @Searchcus and @Order_id>=1000";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Searchcus", "%" + tbcus_name.Text + "%");
            //cmd.Parameters.AddWithValue("@Order_id", "%" + lblorder_id.Text + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lborders.Items.Add(reader["cus_name"]);
                O_id.Add(reader["order_id"]);
            }
            reader.Close();
            con.Close();
            lborders.Enabled = true;
        }

        private void lbOD_product_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strselect_p = lbOD_product.SelectedItem.ToString();

            if (strselect_p != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select product,quantity from orderdetail where product like @Selectproduct";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Selectproduct", "%" + strselect_p + "%");
                SqlDataReader reader = cmd.ExecuteReader();
                //Console.WriteLine(lbOD_product.SelectedIndex.ToString());
                if (reader.Read() == true)
                {
                    amount_count.Text = string.Format("{0}", reader["quantity"]);

                }
                else
                {
                    amount_count.Text = "";
                }
                reader.Close();
                con.Close();

            }
        }

        void Lboutputallproduct()
        {
            lbOD_product.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select*from product1 where product like @Product";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Product", "%" + tbproduct.Text + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbOD_product.Items.Add(reader["product"]);
            }
            reader.Close();
            con.Close();
        }

        void Autosumtotal()//revise order
        {
            int total = 0;
            string strorders_p = lbOD_product.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select price form product1";

            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Searchcus", "%" + strorders_p + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                total += (int)reader["price"] * Convert.ToInt32(amount_count);
            }

            lbltotal.Text = string.Format("{0}", total);
            reader.Close();
            con.Close();
        }

        void comboboxshowall_cus()
        {
            cbcus_name.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select cus_name from customerlist where cus_name like @Newname";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@Newname", "%" + tbcus_name.Text + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                cbcus_name.Items.Add(reader["cus_name"]);
            }
            reader.Close();
            con.Close();



        }
        void cbshowdiscountoption()
        {
            cb_discount.Text = "0";
            cb_discount.Items.Add(0);
            cb_discount.Items.Add(9.5);
            cb_discount.Items.Add(9);
            cb_discount.Items.Add(8.5);
            cb_discount.Items.Add(8);
            cb_discount.Items.Add(7);
            cb_discount.Items.Add(7.5);

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            comboboxshowall_cus();
            cbshowdiscountoption();
        }

        private void cb_discount_SelectedIndexChanged(object sender, EventArgs e)
        {

            cbdiscount();
        }
        void cbdiscount()
        {
            string select = cb_discount.SelectedItem.ToString();
            double D_select = Convert.ToDouble(select), doubleTot;
            // Console.WriteLine(intselect);
            if (select != "0")
            {
                doubleTot = Math.Round((D_select / 10) * (Totallist.Sum()));

                lblfinaltotal.Text = string.Format("{0}", doubleTot);
            }
            else if (select == "" || select == "0")
            {
                lblfinaltotal.Text = lbltotal.Text;
            }



        }

        private void cbcus_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            Lboutputallproduct();

            string strselect_cus = cbcus_name.SelectedItem.ToString();

            if (strselect_cus != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select address,relationship,cus_tel from customerlist where cus_name like @Selectname";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@Selectname", "%" + strselect_cus + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    tbaddress.Text = string.Format("{0}", reader["address"]);
                    tbphone.Text = string.Format("{0}", reader["cus_tel"]);
                    tbclientrelation.Text = string.Format("{0}", reader["relationship"]);

                }
                else
                {
                    amount_count.Text = "";
                }
                reader.Close();
                con.Close();

            }
        }

        

        /*void readnew_orderid()
        {
            string strSQL2;
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select order_id from orders where order_id>=max(order_id) ";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            string O_idtmp = strSQL;
            string strSql2 = "INSERT into orderdetail ([order_id], [pro_id], [product], [quantity], [total], [discount], [finaltotal]) values (@NewO_id,@NewP_id,@Newproduct,@NewQty,@NewTot,@Newdiscount,@NewF_total)";


            cmd.Parameters.AddWithValue("@NewO_id",Convert.ToInt32(O_idtmp) );
            cmd.Parameters.AddWithValue("@NewP-id", Convert.ToInt32(lbOD_product.SelectedIndex));
            cmd.Parameters.AddWithValue("@Newproduct", select_p[0]);
            cmd.Parameters.AddWithValue("@NewQty",select_p[1]);
            cmd.Parameters.AddWithValue("@NewTot", Convert.ToInt32(lbltotal.Text));
            cmd.Parameters.AddWithValue("@Newdiscount", cb_discount.Text);
            cmd.Parameters.AddWithValue("@NewF_total",  Convert.ToInt32(lblfinaltotal.Text));
            

            if (reader.Read())
            {
                cbcus_name.Items.Add(reader["order_id"]);
            }
            reader.Close();
            con.Close();
        }*/


        private void lborderlist_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}    

