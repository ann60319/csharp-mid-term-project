﻿namespace mid_term_project1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.chkpaid = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.chkdelivered = new System.Windows.Forms.CheckBox();
            this.dtpdeliver = new System.Windows.Forms.DateTimePicker();
            this.tbphone = new System.Windows.Forms.TextBox();
            this.btntimenow = new System.Windows.Forms.Button();
            this.tborderdate = new System.Windows.Forms.TextBox();
            this.lbltotal = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblfinaltotal = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnrevise = new System.Windows.Forms.Button();
            this.btnremove = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.tbaddress = new System.Windows.Forms.TextBox();
            this.tbclientrelation = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_discount = new System.Windows.Forms.ComboBox();
            this.lborderlist = new System.Windows.Forms.ListBox();
            this.cbcus_name = new System.Windows.Forms.ComboBox();
            this.lblorder_id = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnconfirm = new System.Windows.Forms.Button();
            this.btnallorders = new System.Windows.Forms.Button();
            this.lborders = new System.Windows.Forms.ListBox();
            this.label20 = new System.Windows.Forms.Label();
            this.amount_count = new System.Windows.Forms.NumericUpDown();
            this.lbOD_product = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.orderlist = new System.Windows.Forms.TabPage();
            this.product = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.btnsearch_p = new System.Windows.Forms.Button();
            this.tbproductsearch = new System.Windows.Forms.TextBox();
            this.lblp_id = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dtpproducedate = new System.Windows.Forms.DateTimePicker();
            this.tbprice = new System.Windows.Forms.TextBox();
            this.tbstockquantity = new System.Windows.Forms.TextBox();
            this.tbproduct = new System.Windows.Forms.TextBox();
            this.lbproduct = new System.Windows.Forms.ListBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnrevise_p = new System.Windows.Forms.Button();
            this.btnremove_p = new System.Windows.Forms.Button();
            this.btnadd_p = new System.Windows.Forms.Button();
            this.btnallproduct = new System.Windows.Forms.Button();
            this.Customer = new System.Windows.Forms.TabPage();
            this.lblcus_id = new System.Windows.Forms.Label();
            this.btnsearch_c = new System.Windows.Forms.Button();
            this.cus_id = new System.Windows.Forms.Label();
            this.lblsum_paid = new System.Windows.Forms.Label();
            this.lblsum_orders = new System.Windows.Forms.Label();
            this.tbcus_tel = new System.Windows.Forms.TextBox();
            this.tbcus_relationship = new System.Windows.Forms.TextBox();
            this.tbcus_address = new System.Windows.Forms.TextBox();
            this.tbcus_name = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lbcus = new System.Windows.Forms.ListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnallcus = new System.Windows.Forms.Button();
            this.btnremove_c = new System.Windows.Forms.Button();
            this.btnrevise_c = new System.Windows.Forms.Button();
            this.btnadd_c = new System.Windows.Forms.Button();
            this.Analysis = new System.Windows.Forms.TabPage();
            this.btnc_rank = new System.Windows.Forms.Button();
            this.btntmroutput = new System.Windows.Forms.Button();
            this.btnnowoutput = new System.Windows.Forms.Button();
            this.lbltimenow = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.amount_count)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.orderlist.SuspendLayout();
            this.product.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.Customer.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.Analysis.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(194, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "~餛飩店電子化系統歡迎您~";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(14, 72);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "客戶姓名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(13, 148);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "連絡電話";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(13, 408);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 28);
            this.label4.TabIndex = 3;
            this.label4.Text = "宅配地址";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(13, 287);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 28);
            this.label5.TabIndex = 4;
            this.label5.Text = "取貨日";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(13, 212);
            this.label6.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 28);
            this.label6.TabIndex = 5;
            this.label6.Text = "訂購日期";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(152, 254);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 21);
            this.label7.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(156, 258);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 21);
            this.label8.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(386, 187);
            this.label9.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 28);
            this.label9.TabIndex = 8;
            this.label9.Text = "數量";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(386, 26);
            this.label10.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 28);
            this.label10.TabIndex = 9;
            this.label10.Text = "產品";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(386, 482);
            this.label11.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 28);
            this.label11.TabIndex = 10;
            this.label11.Text = "小計";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(386, 557);
            this.label12.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 28);
            this.label12.TabIndex = 11;
            this.label12.Text = "總價";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(14, 499);
            this.label13.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 28);
            this.label13.TabIndex = 12;
            this.label13.Text = "備註";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(13, 324);
            this.label14.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 28);
            this.label14.TabIndex = 13;
            this.label14.Text = "付款狀態";
            // 
            // chkpaid
            // 
            this.chkpaid.AutoSize = true;
            this.chkpaid.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkpaid.Location = new System.Drawing.Point(120, 327);
            this.chkpaid.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.chkpaid.Name = "chkpaid";
            this.chkpaid.Size = new System.Drawing.Size(67, 28);
            this.chkpaid.TabIndex = 14;
            this.chkpaid.Text = "已付";
            this.chkpaid.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(13, 360);
            this.label15.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 28);
            this.label15.TabIndex = 16;
            this.label15.Text = "取貨狀態";
            // 
            // chkdelivered
            // 
            this.chkdelivered.AutoSize = true;
            this.chkdelivered.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkdelivered.Location = new System.Drawing.Point(120, 362);
            this.chkdelivered.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.chkdelivered.Name = "chkdelivered";
            this.chkdelivered.Size = new System.Drawing.Size(67, 28);
            this.chkdelivered.TabIndex = 17;
            this.chkdelivered.Text = "已取";
            this.chkdelivered.UseVisualStyleBackColor = true;
            // 
            // dtpdeliver
            // 
            this.dtpdeliver.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtpdeliver.Location = new System.Drawing.Point(117, 287);
            this.dtpdeliver.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.dtpdeliver.Name = "dtpdeliver";
            this.dtpdeliver.Size = new System.Drawing.Size(236, 32);
            this.dtpdeliver.TabIndex = 20;
            // 
            // tbphone
            // 
            this.tbphone.Enabled = false;
            this.tbphone.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbphone.Location = new System.Drawing.Point(117, 150);
            this.tbphone.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbphone.Name = "tbphone";
            this.tbphone.Size = new System.Drawing.Size(237, 32);
            this.tbphone.TabIndex = 22;
            // 
            // btntimenow
            // 
            this.btntimenow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btntimenow.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btntimenow.Location = new System.Drawing.Point(251, 252);
            this.btntimenow.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btntimenow.Name = "btntimenow";
            this.btntimenow.Size = new System.Drawing.Size(99, 30);
            this.btntimenow.TabIndex = 24;
            this.btntimenow.Text = "現在時間";
            this.btntimenow.UseVisualStyleBackColor = false;
            this.btntimenow.Click += new System.EventHandler(this.btntimenow_Click);
            // 
            // tborderdate
            // 
            this.tborderdate.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tborderdate.Location = new System.Drawing.Point(117, 210);
            this.tborderdate.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tborderdate.Name = "tborderdate";
            this.tborderdate.Size = new System.Drawing.Size(236, 32);
            this.tborderdate.TabIndex = 25;
            // 
            // lbltotal
            // 
            this.lbltotal.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbltotal.Location = new System.Drawing.Point(438, 482);
            this.lbltotal.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(83, 28);
            this.lbltotal.TabIndex = 26;
            this.lbltotal.Text = "000";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(386, 516);
            this.label17.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 28);
            this.label17.TabIndex = 27;
            this.label17.Text = "折扣";
            // 
            // lblfinaltotal
            // 
            this.lblfinaltotal.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblfinaltotal.Location = new System.Drawing.Point(438, 556);
            this.lblfinaltotal.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblfinaltotal.Name = "lblfinaltotal";
            this.lblfinaltotal.Size = new System.Drawing.Size(96, 28);
            this.lblfinaltotal.TabIndex = 29;
            this.lblfinaltotal.Text = "000";
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnsearch.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnsearch.Location = new System.Drawing.Point(252, 113);
            this.btnsearch.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(99, 28);
            this.btnsearch.TabIndex = 30;
            this.btnsearch.Text = "搜尋訂單";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnrevise
            // 
            this.btnrevise.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnrevise.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnrevise.Location = new System.Drawing.Point(565, 472);
            this.btnrevise.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnrevise.Name = "btnrevise";
            this.btnrevise.Size = new System.Drawing.Size(121, 46);
            this.btnrevise.TabIndex = 31;
            this.btnrevise.Text = "修改訂單";
            this.btnrevise.UseVisualStyleBackColor = false;
            this.btnrevise.Visible = false;
            this.btnrevise.Click += new System.EventHandler(this.btnrevise_Click);
            // 
            // btnremove
            // 
            this.btnremove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnremove.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnremove.Location = new System.Drawing.Point(691, 529);
            this.btnremove.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(122, 44);
            this.btnremove.TabIndex = 32;
            this.btnremove.Text = "刪除訂單";
            this.btnremove.UseVisualStyleBackColor = false;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnadd.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnadd.Location = new System.Drawing.Point(691, 472);
            this.btnadd.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(121, 46);
            this.btnadd.TabIndex = 33;
            this.btnadd.Text = "新增訂單";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // tbaddress
            // 
            this.tbaddress.Enabled = false;
            this.tbaddress.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbaddress.Location = new System.Drawing.Point(116, 410);
            this.tbaddress.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbaddress.Multiline = true;
            this.tbaddress.Name = "tbaddress";
            this.tbaddress.Size = new System.Drawing.Size(237, 64);
            this.tbaddress.TabIndex = 35;
            // 
            // tbclientrelation
            // 
            this.tbclientrelation.Enabled = false;
            this.tbclientrelation.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbclientrelation.Location = new System.Drawing.Point(117, 505);
            this.tbclientrelation.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbclientrelation.Multiline = true;
            this.tbclientrelation.Name = "tbclientrelation";
            this.tbclientrelation.Size = new System.Drawing.Size(236, 61);
            this.tbclientrelation.TabIndex = 36;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox2.Controls.Add(this.cb_discount);
            this.groupBox2.Controls.Add(this.lborderlist);
            this.groupBox2.Controls.Add(this.cbcus_name);
            this.groupBox2.Controls.Add(this.lblorder_id);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.btnconfirm);
            this.groupBox2.Controls.Add(this.tborderdate);
            this.groupBox2.Controls.Add(this.btnallorders);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.chkpaid);
            this.groupBox2.Controls.Add(this.btnremove);
            this.groupBox2.Controls.Add(this.btnsearch);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.btnrevise);
            this.groupBox2.Controls.Add(this.chkdelivered);
            this.groupBox2.Controls.Add(this.lborders);
            this.groupBox2.Controls.Add(this.btnadd);
            this.groupBox2.Controls.Add(this.tbclientrelation);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.tbaddress);
            this.groupBox2.Controls.Add(this.amount_count);
            this.groupBox2.Controls.Add(this.lbOD_product);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.tbphone);
            this.groupBox2.Controls.Add(this.lblfinaltotal);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lbltotal);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btntimenow);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.dtpdeliver);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(842, 652);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // cb_discount
            // 
            this.cb_discount.FormattingEnabled = true;
            this.cb_discount.Location = new System.Drawing.Point(443, 516);
            this.cb_discount.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.cb_discount.Name = "cb_discount";
            this.cb_discount.Size = new System.Drawing.Size(94, 34);
            this.cb_discount.TabIndex = 54;
            this.cb_discount.SelectedIndexChanged += new System.EventHandler(this.cb_discount_SelectedIndexChanged);
            // 
            // lborderlist
            // 
            this.lborderlist.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lborderlist.FormattingEnabled = true;
            this.lborderlist.HorizontalScrollbar = true;
            this.lborderlist.ItemHeight = 23;
            this.lborderlist.Location = new System.Drawing.Point(390, 306);
            this.lborderlist.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.lborderlist.Name = "lborderlist";
            this.lborderlist.Size = new System.Drawing.Size(274, 142);
            this.lborderlist.TabIndex = 52;
            this.lborderlist.SelectedIndexChanged += new System.EventHandler(this.lborderlist_SelectedIndexChanged);
            // 
            // cbcus_name
            // 
            this.cbcus_name.FormattingEnabled = true;
            this.cbcus_name.Location = new System.Drawing.Point(121, 68);
            this.cbcus_name.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.cbcus_name.Name = "cbcus_name";
            this.cbcus_name.Size = new System.Drawing.Size(232, 34);
            this.cbcus_name.TabIndex = 51;
            this.cbcus_name.SelectedIndexChanged += new System.EventHandler(this.cbcus_name_SelectedIndexChanged);
            // 
            // lblorder_id
            // 
            this.lblorder_id.AutoSize = true;
            this.lblorder_id.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblorder_id.Location = new System.Drawing.Point(116, 26);
            this.lblorder_id.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblorder_id.Name = "lblorder_id";
            this.lblorder_id.Size = new System.Drawing.Size(101, 28);
            this.lblorder_id.TabIndex = 49;
            this.lblorder_id.Text = "order_id";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(13, 26);
            this.label19.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 28);
            this.label19.TabIndex = 48;
            this.label19.Text = "訂單編號";
            // 
            // btnconfirm
            // 
            this.btnconfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnconfirm.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnconfirm.Location = new System.Drawing.Point(515, 222);
            this.btnconfirm.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnconfirm.Name = "btnconfirm";
            this.btnconfirm.Size = new System.Drawing.Size(99, 30);
            this.btnconfirm.TabIndex = 47;
            this.btnconfirm.Text = "確定";
            this.btnconfirm.UseVisualStyleBackColor = false;
            this.btnconfirm.Click += new System.EventHandler(this.btnconfirm_Click);
            // 
            // btnallorders
            // 
            this.btnallorders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnallorders.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnallorders.Location = new System.Drawing.Point(691, 419);
            this.btnallorders.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnallorders.Name = "btnallorders";
            this.btnallorders.Size = new System.Drawing.Size(121, 46);
            this.btnallorders.TabIndex = 46;
            this.btnallorders.Text = "所有訂單";
            this.btnallorders.UseVisualStyleBackColor = false;
            this.btnallorders.Click += new System.EventHandler(this.btnallorders_Click);
            // 
            // lborders
            // 
            this.lborders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lborders.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lborders.FormattingEnabled = true;
            this.lborders.ItemHeight = 23;
            this.lborders.Location = new System.Drawing.Point(675, 20);
            this.lborders.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.lborders.Name = "lborders";
            this.lborders.Size = new System.Drawing.Size(149, 372);
            this.lborders.TabIndex = 44;
            this.lborders.SelectedIndexChanged += new System.EventHandler(this.lborders_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(478, 262);
            this.label20.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 28);
            this.label20.TabIndex = 42;
            this.label20.Text = "訂購清單";
            // 
            // amount_count
            // 
            this.amount_count.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.amount_count.Location = new System.Drawing.Point(390, 222);
            this.amount_count.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.amount_count.Name = "amount_count";
            this.amount_count.Size = new System.Drawing.Size(101, 32);
            this.amount_count.TabIndex = 41;
            // 
            // lbOD_product
            // 
            this.lbOD_product.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbOD_product.FormattingEnabled = true;
            this.lbOD_product.HorizontalScrollbar = true;
            this.lbOD_product.ItemHeight = 23;
            this.lbOD_product.Location = new System.Drawing.Point(390, 58);
            this.lbOD_product.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.lbOD_product.Name = "lbOD_product";
            this.lbOD_product.Size = new System.Drawing.Size(274, 96);
            this.lbOD_product.TabIndex = 37;
            this.lbOD_product.SelectedIndexChanged += new System.EventHandler(this.lbOD_product_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.orderlist);
            this.tabControl1.Controls.Add(this.product);
            this.tabControl1.Controls.Add(this.Customer);
            this.tabControl1.Controls.Add(this.Analysis);
            this.tabControl1.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(0, 74);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(849, 683);
            this.tabControl1.TabIndex = 38;
            // 
            // orderlist
            // 
            this.orderlist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.orderlist.Controls.Add(this.groupBox2);
            this.orderlist.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.orderlist.Location = new System.Drawing.Point(4, 32);
            this.orderlist.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.orderlist.Name = "orderlist";
            this.orderlist.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.orderlist.Size = new System.Drawing.Size(841, 647);
            this.orderlist.TabIndex = 0;
            this.orderlist.Text = "訂購單";
            // 
            // product
            // 
            this.product.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.product.Controls.Add(this.label18);
            this.product.Controls.Add(this.btnsearch_p);
            this.product.Controls.Add(this.tbproductsearch);
            this.product.Controls.Add(this.lblp_id);
            this.product.Controls.Add(this.label16);
            this.product.Controls.Add(this.dtpproducedate);
            this.product.Controls.Add(this.tbprice);
            this.product.Controls.Add(this.tbstockquantity);
            this.product.Controls.Add(this.tbproduct);
            this.product.Controls.Add(this.lbproduct);
            this.product.Controls.Add(this.label25);
            this.product.Controls.Add(this.label24);
            this.product.Controls.Add(this.label23);
            this.product.Controls.Add(this.label21);
            this.product.Controls.Add(this.groupBox3);
            this.product.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.product.Location = new System.Drawing.Point(4, 32);
            this.product.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.product.Name = "product";
            this.product.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.product.Size = new System.Drawing.Size(841, 647);
            this.product.TabIndex = 1;
            this.product.Text = "產品資料庫";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(648, 291);
            this.label18.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 28);
            this.label18.TabIndex = 40;
            this.label18.Text = "搜尋";
            // 
            // btnsearch_p
            // 
            this.btnsearch_p.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnsearch_p.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnsearch_p.Location = new System.Drawing.Point(689, 369);
            this.btnsearch_p.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnsearch_p.Name = "btnsearch_p";
            this.btnsearch_p.Size = new System.Drawing.Size(121, 47);
            this.btnsearch_p.TabIndex = 36;
            this.btnsearch_p.Text = "查詢產品";
            this.btnsearch_p.UseVisualStyleBackColor = false;
            this.btnsearch_p.Click += new System.EventHandler(this.btnsearch_p_Click);
            // 
            // tbproductsearch
            // 
            this.tbproductsearch.Location = new System.Drawing.Point(647, 329);
            this.tbproductsearch.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbproductsearch.Name = "tbproductsearch";
            this.tbproductsearch.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbproductsearch.Size = new System.Drawing.Size(166, 36);
            this.tbproductsearch.TabIndex = 39;
            // 
            // lblp_id
            // 
            this.lblp_id.AutoSize = true;
            this.lblp_id.Location = new System.Drawing.Point(415, 99);
            this.lblp_id.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblp_id.Name = "lblp_id";
            this.lblp_id.Size = new System.Drawing.Size(56, 28);
            this.lblp_id.TabIndex = 12;
            this.lblp_id.Text = "p_id";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(259, 99);
            this.label16.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 28);
            this.label16.TabIndex = 11;
            this.label16.Text = "產品編號";
            // 
            // dtpproducedate
            // 
            this.dtpproducedate.Location = new System.Drawing.Point(411, 282);
            this.dtpproducedate.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.dtpproducedate.Name = "dtpproducedate";
            this.dtpproducedate.Size = new System.Drawing.Size(194, 36);
            this.dtpproducedate.TabIndex = 10;
            // 
            // tbprice
            // 
            this.tbprice.Location = new System.Drawing.Point(411, 215);
            this.tbprice.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbprice.Name = "tbprice";
            this.tbprice.Size = new System.Drawing.Size(192, 36);
            this.tbprice.TabIndex = 9;
            // 
            // tbstockquantity
            // 
            this.tbstockquantity.Location = new System.Drawing.Point(411, 332);
            this.tbstockquantity.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbstockquantity.Name = "tbstockquantity";
            this.tbstockquantity.Size = new System.Drawing.Size(192, 36);
            this.tbstockquantity.TabIndex = 8;
            // 
            // tbproduct
            // 
            this.tbproduct.Location = new System.Drawing.Point(412, 150);
            this.tbproduct.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbproduct.Name = "tbproduct";
            this.tbproduct.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbproduct.Size = new System.Drawing.Size(192, 36);
            this.tbproduct.TabIndex = 7;
            // 
            // lbproduct
            // 
            this.lbproduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbproduct.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbproduct.FormattingEnabled = true;
            this.lbproduct.ItemHeight = 23;
            this.lbproduct.Location = new System.Drawing.Point(27, 35);
            this.lbproduct.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.lbproduct.Name = "lbproduct";
            this.lbproduct.Size = new System.Drawing.Size(200, 349);
            this.lbproduct.TabIndex = 6;
            this.lbproduct.SelectedIndexChanged += new System.EventHandler(this.lbproduct_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(298, 332);
            this.label25.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 28);
            this.label25.TabIndex = 5;
            this.label25.Text = "庫存";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(267, 282);
            this.label24.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 28);
            this.label24.TabIndex = 4;
            this.label24.Text = "製造日期";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(298, 210);
            this.label23.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 28);
            this.label23.TabIndex = 3;
            this.label23.Text = "售價";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(298, 150);
            this.label21.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 28);
            this.label21.TabIndex = 2;
            this.label21.Text = "產品";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnrevise_p);
            this.groupBox3.Controls.Add(this.btnremove_p);
            this.groupBox3.Controls.Add(this.btnadd_p);
            this.groupBox3.Controls.Add(this.btnallproduct);
            this.groupBox3.Location = new System.Drawing.Point(66, 420);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox3.Size = new System.Drawing.Size(722, 70);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // btnrevise_p
            // 
            this.btnrevise_p.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnrevise_p.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnrevise_p.Location = new System.Drawing.Point(363, 18);
            this.btnrevise_p.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnrevise_p.Name = "btnrevise_p";
            this.btnrevise_p.Size = new System.Drawing.Size(177, 46);
            this.btnrevise_p.TabIndex = 37;
            this.btnrevise_p.Text = "修改產品內容";
            this.btnrevise_p.UseVisualStyleBackColor = false;
            this.btnrevise_p.Click += new System.EventHandler(this.btnrevise_p_Click);
            // 
            // btnremove_p
            // 
            this.btnremove_p.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnremove_p.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnremove_p.Location = new System.Drawing.Point(565, 18);
            this.btnremove_p.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnremove_p.Name = "btnremove_p";
            this.btnremove_p.Size = new System.Drawing.Size(151, 46);
            this.btnremove_p.TabIndex = 35;
            this.btnremove_p.Text = "刪除產品";
            this.btnremove_p.UseVisualStyleBackColor = false;
            this.btnremove_p.Click += new System.EventHandler(this.btnremove_p_Click);
            // 
            // btnadd_p
            // 
            this.btnadd_p.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnadd_p.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnadd_p.Location = new System.Drawing.Point(203, 18);
            this.btnadd_p.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnadd_p.Name = "btnadd_p";
            this.btnadd_p.Size = new System.Drawing.Size(134, 46);
            this.btnadd_p.TabIndex = 34;
            this.btnadd_p.Text = "新增產品";
            this.btnadd_p.UseVisualStyleBackColor = false;
            this.btnadd_p.Click += new System.EventHandler(this.btnadd_p_Click);
            // 
            // btnallproduct
            // 
            this.btnallproduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnallproduct.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnallproduct.Location = new System.Drawing.Point(10, 18);
            this.btnallproduct.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnallproduct.Name = "btnallproduct";
            this.btnallproduct.Size = new System.Drawing.Size(170, 46);
            this.btnallproduct.TabIndex = 38;
            this.btnallproduct.Text = "所有產品列表";
            this.btnallproduct.UseVisualStyleBackColor = false;
            this.btnallproduct.Click += new System.EventHandler(this.btnallproduct_Click);
            // 
            // Customer
            // 
            this.Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Customer.Controls.Add(this.lblcus_id);
            this.Customer.Controls.Add(this.btnsearch_c);
            this.Customer.Controls.Add(this.cus_id);
            this.Customer.Controls.Add(this.lblsum_paid);
            this.Customer.Controls.Add(this.lblsum_orders);
            this.Customer.Controls.Add(this.tbcus_tel);
            this.Customer.Controls.Add(this.tbcus_relationship);
            this.Customer.Controls.Add(this.tbcus_address);
            this.Customer.Controls.Add(this.tbcus_name);
            this.Customer.Controls.Add(this.label31);
            this.Customer.Controls.Add(this.label30);
            this.Customer.Controls.Add(this.label29);
            this.Customer.Controls.Add(this.label28);
            this.Customer.Controls.Add(this.label27);
            this.Customer.Controls.Add(this.label26);
            this.Customer.Controls.Add(this.lbcus);
            this.Customer.Controls.Add(this.groupBox4);
            this.Customer.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Customer.Location = new System.Drawing.Point(4, 32);
            this.Customer.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.Customer.Name = "Customer";
            this.Customer.Size = new System.Drawing.Size(841, 647);
            this.Customer.TabIndex = 2;
            this.Customer.Text = "客戶資料庫";
            // 
            // lblcus_id
            // 
            this.lblcus_id.AutoSize = true;
            this.lblcus_id.Location = new System.Drawing.Point(450, 32);
            this.lblcus_id.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblcus_id.Name = "lblcus_id";
            this.lblcus_id.Size = new System.Drawing.Size(103, 28);
            this.lblcus_id.TabIndex = 15;
            this.lblcus_id.Text = "lblcus_id";
            // 
            // btnsearch_c
            // 
            this.btnsearch_c.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnsearch_c.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnsearch_c.Location = new System.Drawing.Point(534, 124);
            this.btnsearch_c.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnsearch_c.Name = "btnsearch_c";
            this.btnsearch_c.Size = new System.Drawing.Size(90, 45);
            this.btnsearch_c.TabIndex = 28;
            this.btnsearch_c.Text = "搜尋";
            this.btnsearch_c.UseVisualStyleBackColor = false;
            this.btnsearch_c.Click += new System.EventHandler(this.btnsearch_c_Click);
            // 
            // cus_id
            // 
            this.cus_id.AutoSize = true;
            this.cus_id.Location = new System.Drawing.Point(312, 32);
            this.cus_id.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.cus_id.Name = "cus_id";
            this.cus_id.Size = new System.Drawing.Size(118, 28);
            this.cus_id.TabIndex = 14;
            this.cus_id.Text = "客 戶 編 號";
            // 
            // lblsum_paid
            // 
            this.lblsum_paid.Location = new System.Drawing.Point(455, 394);
            this.lblsum_paid.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblsum_paid.Name = "lblsum_paid";
            this.lblsum_paid.Size = new System.Drawing.Size(169, 33);
            this.lblsum_paid.TabIndex = 13;
            this.lblsum_paid.Text = "000";
            this.lblsum_paid.Visible = false;
            // 
            // lblsum_orders
            // 
            this.lblsum_orders.Location = new System.Drawing.Point(456, 350);
            this.lblsum_orders.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblsum_orders.Name = "lblsum_orders";
            this.lblsum_orders.Size = new System.Drawing.Size(169, 38);
            this.lblsum_orders.TabIndex = 12;
            this.lblsum_orders.Text = "000";
            this.lblsum_orders.Visible = false;
            // 
            // tbcus_tel
            // 
            this.tbcus_tel.Location = new System.Drawing.Point(454, 179);
            this.tbcus_tel.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbcus_tel.Name = "tbcus_tel";
            this.tbcus_tel.Size = new System.Drawing.Size(171, 36);
            this.tbcus_tel.TabIndex = 11;
            // 
            // tbcus_relationship
            // 
            this.tbcus_relationship.Location = new System.Drawing.Point(454, 291);
            this.tbcus_relationship.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbcus_relationship.Name = "tbcus_relationship";
            this.tbcus_relationship.Size = new System.Drawing.Size(171, 36);
            this.tbcus_relationship.TabIndex = 10;
            // 
            // tbcus_address
            // 
            this.tbcus_address.Location = new System.Drawing.Point(454, 237);
            this.tbcus_address.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbcus_address.Name = "tbcus_address";
            this.tbcus_address.Size = new System.Drawing.Size(171, 36);
            this.tbcus_address.TabIndex = 9;
            // 
            // tbcus_name
            // 
            this.tbcus_name.Location = new System.Drawing.Point(455, 83);
            this.tbcus_name.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.tbcus_name.Name = "tbcus_name";
            this.tbcus_name.Size = new System.Drawing.Size(171, 36);
            this.tbcus_name.TabIndex = 8;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(227, 394);
            this.label31.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(210, 28);
            this.label31.TabIndex = 7;
            this.label31.Text = "今年度累計下單金額";
            this.label31.Visible = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(310, 181);
            this.label30.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(122, 28);
            this.label30.TabIndex = 6;
            this.label30.Text = "電           話";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(265, 241);
            this.label29.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(172, 28);
            this.label29.TabIndex = 5;
            this.label29.Text = "宅    配    地    址";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(236, 297);
            this.label28.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(202, 28);
            this.label28.TabIndex = 4;
            this.label28.Text = "與 其 他 客 戶 關 係";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(247, 350);
            this.label27.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(188, 28);
            this.label27.TabIndex = 3;
            this.label27.Text = "今年度累計下單數";
            this.label27.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(311, 89);
            this.label26.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(122, 28);
            this.label26.TabIndex = 2;
            this.label26.Text = "姓           名";
            // 
            // lbcus
            // 
            this.lbcus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbcus.FormattingEnabled = true;
            this.lbcus.ItemHeight = 26;
            this.lbcus.Location = new System.Drawing.Point(20, 23);
            this.lbcus.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.lbcus.Name = "lbcus";
            this.lbcus.Size = new System.Drawing.Size(190, 342);
            this.lbcus.TabIndex = 1;
            this.lbcus.SelectedIndexChanged += new System.EventHandler(this.lbcus_SelectedIndexChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnallcus);
            this.groupBox4.Controls.Add(this.btnremove_c);
            this.groupBox4.Controls.Add(this.btnrevise_c);
            this.groupBox4.Controls.Add(this.btnadd_c);
            this.groupBox4.Location = new System.Drawing.Point(33, 465);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox4.Size = new System.Drawing.Size(603, 76);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // btnallcus
            // 
            this.btnallcus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnallcus.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnallcus.Location = new System.Drawing.Point(11, 24);
            this.btnallcus.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnallcus.Name = "btnallcus";
            this.btnallcus.Size = new System.Drawing.Size(130, 48);
            this.btnallcus.TabIndex = 29;
            this.btnallcus.Text = "客戶清單";
            this.btnallcus.UseVisualStyleBackColor = false;
            this.btnallcus.Click += new System.EventHandler(this.btnallcus_Click);
            // 
            // btnremove_c
            // 
            this.btnremove_c.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnremove_c.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnremove_c.Location = new System.Drawing.Point(455, 24);
            this.btnremove_c.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnremove_c.Name = "btnremove_c";
            this.btnremove_c.Size = new System.Drawing.Size(130, 48);
            this.btnremove_c.TabIndex = 27;
            this.btnremove_c.Text = "刪除資料";
            this.btnremove_c.UseVisualStyleBackColor = false;
            this.btnremove_c.Click += new System.EventHandler(this.btnremove_c_Click);
            // 
            // btnrevise_c
            // 
            this.btnrevise_c.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnrevise_c.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnrevise_c.Location = new System.Drawing.Point(308, 24);
            this.btnrevise_c.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnrevise_c.Name = "btnrevise_c";
            this.btnrevise_c.Size = new System.Drawing.Size(130, 48);
            this.btnrevise_c.TabIndex = 26;
            this.btnrevise_c.Text = "修改資料";
            this.btnrevise_c.UseVisualStyleBackColor = false;
            this.btnrevise_c.Click += new System.EventHandler(this.btnrevise_c_Click);
            // 
            // btnadd_c
            // 
            this.btnadd_c.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnadd_c.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnadd_c.Location = new System.Drawing.Point(160, 24);
            this.btnadd_c.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnadd_c.Name = "btnadd_c";
            this.btnadd_c.Size = new System.Drawing.Size(130, 48);
            this.btnadd_c.TabIndex = 25;
            this.btnadd_c.Text = "新增資料";
            this.btnadd_c.UseVisualStyleBackColor = false;
            this.btnadd_c.Click += new System.EventHandler(this.btnadd_c_Click);
            // 
            // Analysis
            // 
            this.Analysis.BackColor = System.Drawing.Color.Gray;
            this.Analysis.Controls.Add(this.btnc_rank);
            this.Analysis.Controls.Add(this.btntmroutput);
            this.Analysis.Controls.Add(this.btnnowoutput);
            this.Analysis.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Analysis.Location = new System.Drawing.Point(4, 32);
            this.Analysis.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.Analysis.Name = "Analysis";
            this.Analysis.Size = new System.Drawing.Size(841, 647);
            this.Analysis.TabIndex = 3;
            this.Analysis.Text = "統計與分析";
            // 
            // btnc_rank
            // 
            this.btnc_rank.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnc_rank.Location = new System.Drawing.Point(540, 254);
            this.btnc_rank.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnc_rank.Name = "btnc_rank";
            this.btnc_rank.Size = new System.Drawing.Size(183, 46);
            this.btnc_rank.TabIndex = 2;
            this.btnc_rank.Text = "客戶消費額排行榜";
            this.btnc_rank.UseVisualStyleBackColor = false;
            // 
            // btntmroutput
            // 
            this.btntmroutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btntmroutput.Location = new System.Drawing.Point(540, 174);
            this.btntmroutput.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btntmroutput.Name = "btntmroutput";
            this.btntmroutput.Size = new System.Drawing.Size(138, 46);
            this.btntmroutput.TabIndex = 1;
            this.btntmroutput.Text = "明日出貨訂單";
            this.btntmroutput.UseVisualStyleBackColor = false;
            // 
            // btnnowoutput
            // 
            this.btnnowoutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnnowoutput.Location = new System.Drawing.Point(540, 98);
            this.btnnowoutput.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btnnowoutput.Name = "btnnowoutput";
            this.btnnowoutput.Size = new System.Drawing.Size(138, 46);
            this.btnnowoutput.TabIndex = 0;
            this.btnnowoutput.Text = "今日出貨訂單";
            this.btnnowoutput.UseVisualStyleBackColor = false;
            // 
            // lbltimenow
            // 
            this.lbltimenow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbltimenow.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbltimenow.Location = new System.Drawing.Point(588, 65);
            this.lbltimenow.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbltimenow.Name = "lbltimenow";
            this.lbltimenow.Size = new System.Drawing.Size(247, 31);
            this.lbltimenow.TabIndex = 39;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(835, 692);
            this.Controls.Add(this.lbltimenow);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.Name = "Form1";
            this.Text = "餛飩店";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.amount_count)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.orderlist.ResumeLayout(false);
            this.product.ResumeLayout(false);
            this.product.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.Customer.ResumeLayout(false);
            this.Customer.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.Analysis.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chkpaid;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkdelivered;
        private System.Windows.Forms.DateTimePicker dtpdeliver;
        private System.Windows.Forms.TextBox tbphone;
        private System.Windows.Forms.Button btntimenow;
        private System.Windows.Forms.TextBox tborderdate;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblfinaltotal;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnrevise;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox tbaddress;
        private System.Windows.Forms.TextBox tbclientrelation;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage orderlist;
        private System.Windows.Forms.TabPage product;
        private System.Windows.Forms.TabPage Customer;
        private System.Windows.Forms.TabPage Analysis;
        private System.Windows.Forms.NumericUpDown amount_count;
        private System.Windows.Forms.ListBox lbOD_product;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnrevise_p;
        private System.Windows.Forms.Button btnsearch_p;
        private System.Windows.Forms.Button btnremove_p;
        private System.Windows.Forms.Button btnadd_p;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnadd_c;
        private System.Windows.Forms.Label lbltimenow;
        private System.Windows.Forms.DateTimePicker dtpproducedate;
        private System.Windows.Forms.TextBox tbprice;
        private System.Windows.Forms.TextBox tbstockquantity;
        private System.Windows.Forms.TextBox tbproduct;
        private System.Windows.Forms.ListBox lbproduct;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbcus_name;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ListBox lbcus;
        private System.Windows.Forms.Button btnsearch_c;
        private System.Windows.Forms.Button btnremove_c;
        private System.Windows.Forms.Button btnrevise_c;
        private System.Windows.Forms.TextBox tbcus_tel;
        private System.Windows.Forms.TextBox tbcus_relationship;
        private System.Windows.Forms.TextBox tbcus_address;
        private System.Windows.Forms.ListBox lborders;
        private System.Windows.Forms.Label lblsum_paid;
        private System.Windows.Forms.Label lblsum_orders;
        private System.Windows.Forms.Button btnc_rank;
        private System.Windows.Forms.Button btntmroutput;
        private System.Windows.Forms.Button btnnowoutput;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblp_id;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnallproduct;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbproductsearch;
        private System.Windows.Forms.Button btnallcus;
        private System.Windows.Forms.Label lblcus_id;
        private System.Windows.Forms.Label cus_id;
        private System.Windows.Forms.Button btnallorders;
        private System.Windows.Forms.Button btnconfirm;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblorder_id;
        private System.Windows.Forms.ComboBox cbcus_name;
        private System.Windows.Forms.ListBox lborderlist;
        private System.Windows.Forms.ComboBox cb_discount;
    }
}

